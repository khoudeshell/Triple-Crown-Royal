﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using HorseLeague.Models;
using HorseLeague.Models.DataAccess;
using System.Collections.Generic;
using System.Web.Mvc;

namespace HorseLeague.Views.Shared
{
    public class UIFunctions
    {
        public static IList<SelectListItem> PopulateHorseDropDown(LeagueRace leagueRace, IList<UserRaceDetail> userPicks, 
            BetTypes betType, System.Guid userId)
        {
            IList<SelectListItem> items = new List<SelectListItem>();

            UserRaceDetail userRaceDetail = GetUserSelection(userPicks, betType, userId);

            //Add the default node
            SelectListItem item = new SelectListItem();
            item.Text = "";
            item.Value = "-1";
            items.Add(item);

            foreach (RaceDetail rd in leagueRace.RaceDetails)
            {
                item = new SelectListItem();
                item.Text = FormatHorseNameForDisplay(rd.PostPosition, rd.Horse.Name);
                item.Value = rd.RaceDetailId.ToString();

                if (userRaceDetail != null && userRaceDetail.RaceDetailId == rd.RaceDetailId)
                {
                    item.Selected = true;
                }

                items.Add(item);
            }

            return items;
        }

        public static string FormatHorseNameForDisplay(int postPosition, string horseName)
        {
            return String.Format("{0} - {1}", postPosition, horseName);
        }

        public static UserRaceDetail GetUserSelection(IList<UserRaceDetail> userPicks, BetTypes betType, System.Guid userId)
        {
            return (from up in userPicks
                         where up.BetType == Convert.ToInt32(betType) && up.UserId == userId
                         select up).FirstOrDefault();
        }

        public static RaceDetailPayout GetPayout(BetTypes payoutType, LeagueRace leagueRace)
        {
            return (from rd in leagueRace.RaceDetailPayouts
                                    where rd.BetType == Convert.ToInt32(payoutType)
                                    select rd).FirstOrDefault();
        }
       
        public static RaceDetailPayout GetRaceDetailPayoutForAUserSelection(LeagueRace leagueRace, UserRaceDetail userSelection)
        {
            return (from rdp in leagueRace.RaceDetailPayouts
                                    where rdp.RaceDetailId == userSelection.RaceDetailId
                                    select rdp).FirstOrDefault();
        }

        public static string GetBetTypeValueFromPayout(double? amount)
        {
            return (amount == null || amount == 0.0D) ? "-" : amount.ToString();
        }
    }
}
